import { Component } from '@angular/core';

@Component({
  selector: 'app-meta-tags',
  imports: [],
  templateUrl: './meta-tags.html',
  styleUrl: './meta-tags.css'
})
export class MetaTags {

}
