import { Component } from '@angular/core';

@Component({
  selector: 'app-schema',
  imports: [],
  templateUrl: './schema.html',
  styleUrl: './schema.css'
})
export class Schema {

}
