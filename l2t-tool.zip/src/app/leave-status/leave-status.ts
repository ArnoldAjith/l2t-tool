import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-status',
  imports: [],
  templateUrl: './leave-status.html',
  styleUrl: './leave-status.css'
})
export class LeaveStatus {

}
