import { Component } from '@angular/core';

@Component({
  selector: 'app-conversion-tracking',
  imports: [],
  templateUrl: './conversion-tracking.html',
  styleUrl: './conversion-tracking.css',
})
export class ConversionTracking {

}
