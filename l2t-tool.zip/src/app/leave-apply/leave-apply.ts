import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-apply',
  imports: [],
  templateUrl: './leave-apply.html',
  styleUrl: './leave-apply.css'
})
export class LeaveApply {

}
